<!DOCTYPE html>
<html lang="en">

<head>

    <title>DAMS - <?php echo e($title ?? ''); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('libs/bower/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('libs/bower/material-design-iconic-font/dist/css/material-design-iconic-font.css')); ?>">
    <!-- build:css assets/css/app.min.css -->
    <link rel="stylesheet" href="<?php echo e(asset('libs/bower/animate.css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('libs/bower/fullcalendar/dist/fullcalendar.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('libs/bower/perfect-scrollbar/css/perfect-scrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/core.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
    <!-- endbuild -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,300">
    <script src="libs/bower/breakpoints.js/dist/breakpoints.min.js"></script>
    <script>
        Breakpoints();
    </script>
</head>

<body class="menubar-left menubar-unfold menubar-light theme-primary">
    <!--============= start main area -->


    <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <?php echo $__env->yieldContent('content'); ?>
            </section><!-- #dash-content -->
        </div><!-- .wrap -->
        <!-- APP FOOTER -->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /#app-footer -->
    </main>
    <!--========== END app main -->

    <?php echo $__env->make('layouts.partials.customizer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <!-- build:js assets/js/core.min.js -->
    <script src="<?php echo e(asset('libs/bower/jquery/dist/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/bower/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/bower/jQuery-Storage-API/jquery.storageapi.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/bower/bootstrap-sass/assets/javascripts/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/bower/jquery-slimscroll/jquery.slimscroll.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/bower/perfect-scrollbar/js/perfect-scrollbar.jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/bower/PACE/pace.min.js')); ?>"></script>
    <!-- endbuild -->

    <!-- build:js assets/js/app.min.js -->
    <script src="<?php echo e(asset('assets/js/library.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <!-- endbuild -->
    <script src="<?php echo e(asset('libs/bower/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/bower/fullcalendar/dist/fullcalendar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/fullcalendar.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\wamp64\www\Doctor-Appointment-System\resources\views/layouts/doctor.blade.php ENDPATH**/ ?>
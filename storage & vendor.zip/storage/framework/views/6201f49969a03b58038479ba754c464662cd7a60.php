<div class="wrap p-t-0">
    <footer class="app-footer">

        <div class="copyright pull-left">Doctor Appointment Management System </div>

    </footer>
</div>
<?php /**PATH C:\wamp64\www\Doctor-Appointment-System\resources\views/layouts/footer.blade.php ENDPATH**/ ?>



<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="p-lg-5 p-4">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4">Contact Info</h1>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success" id="alert_msg">
                                <p><?php echo e($message); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('error')): ?>
                            <div class="alert alert-danger" id="alert_msg">
                                <p><?php echo e($message); ?></p>
                            </div>
                        <?php endif; ?>
                        <form class="user" id="contactInfoUpdate" method="POST" enctype="multipart/form-data" action="<?php echo e(route('adminContactInfoUpdate')); ?>">
                        <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <div class="col-sm-12 mb-3 ">
                                    <label for="name" class="text-dark">Name <span class="text-danger">*</span></label>
                                    <input type="text" name="name" class="form-control form_input" id="name" value="<?php echo e($contact_info->name); ?>" placeholder="Name">
                                </div>
                                <input type="hidden" name="bid" value="<?php echo e(base64_encode($contact_info->id)); ?>"/>
                                
                                <div class="col-sm-12 mb-3 ">
                                    <label for="email" class="text-dark">Email <span class="text-danger">*</span></label>
                                    <input type="email" name="email" class="form-control form_input" id="email" value="<?php echo e($contact_info->email); ?>" placeholder="Email">
                                </div>
                                
                                
                                
                                <div class="col-sm-12 mb-3">
                                    <label for="phone_no" class="text-dark">Phone No<span class="text-danger">*</span></label>
                                    <input type="text" name="phone_no" class="form-control form_input" value="<?php echo e($contact_info->phone_no); ?>" pattern="[-\d]*" id="phone_no" placeholder="Full Price">
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="whatsapp_no" class="text-dark">Whatsapp No<span class="text-danger">*</span></label>
                                    <input type="text" name="whatsapp_no" class="form-control form_input" value="<?php echo e($contact_info->whatsapp_no); ?>" id="whatsapp_no" pattern="[-\d]*" placeholder="Whatsapp No">
                                </div>
                                

                                <div class="col-sm-12 mb-3 ">
                                    <label for="facebook" class="text-dark">Facebook URL<span class="text-danger">*</span></label>
                                    <input type="text" name="facebook" class="form-control form_input" id="facebook" value="<?php echo e($contact_info->facebook); ?>" placeholder="Facebook URL">
                                </div>

                                <div class="col-sm-12 mb-3 ">
                                    <label for="instagram" class="text-dark">Instagram URL<span class="text-danger">*</span></label>
                                    <input type="text" name="instagram" class="form-control form_input" id="instagram" value="<?php echo e($contact_info->instagram); ?>" placeholder="Instagram URL">
                                </div>

                                
                            </div>
                            <div class="form-group row">
                                    <div class="col-sm-12 mb-3">
                                        <label for="meta_title" class="text-dark">Meta Title<span class="text-danger">*</span></label>
                                        <input type="text" name="meta_title" value="<?php echo e($contact_info->meta_title ? $contact_info->meta_title : ''); ?>" class="form-control form_input" id="meta_title" placeholder="Meta Title">
                                    </div>
                                    <div class="form-group col-sm-12">
                                        <label for="meta_description" class="text-dark">Meta Description <span class="text-danger">*</span></label>
                                        <textarea class="w-100 text-area form_input" value="<?php echo e($contact_info->meta_description ? $contact_info->meta_description : ''); ?>" cols="42" rows="8" name="meta_description" style="border-radius:8px; border:1px solid #d1d3e2 !important;" placeholder="Meta Description"><?php echo e($contact_info->meta_description ? $contact_info->meta_description : ''); ?></textarea>
                                    </div>
                                </div>  
                                <div class="float-right mb-4">
                                    <a href="<?php echo e(route('adminInventory')); ?>" class="btn btn-user btn-outline btn-outline-secondary">
                                        <i class="fa-solid fa-xmark"></i> Cancel
                                    </a>
                                    <button name="update_inventory" type="submit" value="1" class="btn btn-success btn-user">
                                        <i class="fa-solid fa-up-right-from-square"></i> Submit
                                    </button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
<?php echo JsValidator::formRequest('App\Http\Requests\Admin\UpdateContactInfoRequest','#contactInfoUpdate'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/admin/contact_info/list.blade.php ENDPATH**/ ?>
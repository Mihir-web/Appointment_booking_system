<?php $__env->startSection('content'); ?>
    <div class="simple-page-form animated flipInY" id="login-form">
        <h4 class="form-title m-b-xl text-center">Sign Up With Your DAMS Account</h4>
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input id="name" type="text" class="form-control" placeholder="Full Name" name="name"
                    required="true">
            </div>

            <div class="form-group">
                <input id="email" type="email" class="form-control" placeholder="Email" name="email"
                    required="true">
            </div>
            <div class="form-group">
                <input id="MobileNumber" type="text" class="form-control" placeholder="Mobile" name="MobileNumber"
                    maxlength="10" pattern="[0-9]+" required="true">
            </div>
            <div class="form-group">
                <select class="form-control" name="Specialization">
                    <option value="">Choose Specialization</option>
                    <?php $__currentLoopData = $Specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->Specialization); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>

            </div>

            <div class="form-group">
                <input id="password" type="password" class="form-control" placeholder="Password" name="password"
                    required="true">
            </div>

            <div class="form-group">
                <input id="password_confirmation" type="password" class="form-control" placeholder="Confirm Password"
                    name="password_confirmation" required="true">
            </div>

            <input type="submit" class="btn btn-primary" value="Register" name="submit">
        </form>
        <hr />

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div><!-- #login-form -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <p>
        <small>Do you have an account ?</small>
        <a href="<?php echo e(route('login')); ?>">SIGN IN</a>
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Login.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Doctor-Appointment-System\resources\views/auth/register.blade.php ENDPATH**/ ?>
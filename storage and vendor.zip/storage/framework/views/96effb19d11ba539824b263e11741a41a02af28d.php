

<?php $__env->startSection('content'); ?>
<aside class="kenburns-section" id="kenburnsSliderContainer" data-overlay-dark="7">
        <div class="kenburns-inner h-100">
            <div class="v-middle caption">
                <div class="container">
                    <div class="row h-100">
                        <div class="col-md-12 text-center">
                            
                            <h1 class="wow zoomIn">Thank You!</h1>
                            <h5 class="wow fadeInUp">We will get back to you soon!</h5>
                            <a href="<?php echo e(route('homepage')); ?>" class="button-1 mt-15 mb-15 mr-15 wow fadeInLeft">Back to Home page <span
                                    class="ti-arrow-top-right"></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </aside>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/thankyou.blade.php ENDPATH**/ ?>
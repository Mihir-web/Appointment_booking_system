


<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="p-lg-5 p-4">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4">Add Happy Client</h1>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('error')): ?>
                            <div class="alert alert-danger" id="alert_msg">
                                <p><?php echo e($message); ?></p>
                            </div>
                        <?php endif; ?>

                        <form class="user" id="happyclientUpdate" method="POST" enctype="multipart/form-data" action="<?php echo e(route('adminHappyClientsUpdate')); ?>">
                        <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="message" class="text-dark">Message (Max Allowed length is 125 charactes)<span class="text-danger">*</span></label>
                                    <textarea class="w-100 text-area form_input" maxlength="125" id="html-content" cols="42" rows="8" name="message" style="border-radius:8px; border:1px solid #d1d3e2 !important;" placeholder="Message" value="<?php echo e($happy_client->message); ?>"><?php echo e($happy_client->message); ?></textarea>
                                </div>
                                <div class="form-group row photo_upload">
                                    <label for="photo" class="col-12 text-dark">
                                        Upload Photo <span class="text-danger">*</span>
                                        <div class="image_upload text-center p-2 form_input" style="height:auto; width:100%; border-radius:10px; border:dashed 2px #d1d3e2;">
                                            <img src="<?php echo e(asset('assets/img/happyClients/'.$happy_client->photo)); ?>" height="80px" width="80px" class="preview_image"/>
                                            <input type="file" name="photo" id="photo" style="width:1px; height:1px; visibility: hidden;" accept="image/*"/>
                                            <p class="text-secondary">Only JPG, and JPEG files are allowed, and file should not exceed size of 5mb.</p>
                                        </div>
                                    </label>
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="display_order" class="text-dark">Display order <span class="text-danger">*</span></label>
                                    <select class="form-control form_input" name="display_order" id="display_order">
                                        <option disabled value="" selected disabled>Select Display order</option>
                                        <?php for($i=1; $i<=$happy_client_count; $i++): ?> 
                                        <option value="<?php echo e($i); ?>" <?php echo e($happy_client->display_order == $i ? "selected":""); ?>><?php echo e($i); ?></option>
                                        <?php endfor; ?>                                     
                                    </select>
                                </div>
                                <input type="hidden" value="<?php echo e($happy_client->photo); ?>" name="photo_hidden">
                                <input type="hidden" name="bid" value="<?php echo e(base64_encode($happy_client->id)); ?>"/>
                                <hr>
                                <div class="float-right mb-4">
                                    <a href="<?php echo e(route('adminHappyClients')); ?>" class="btn btn-user btn-outline btn-outline-secondary">
                                        <i class="fa-solid fa-xmark"></i> Cancel
                                    </a>
                                    <button name="add_product" type="submit" value="1" class="btn btn-success btn-user">
                                        <i class="fa-solid fa-up-right-from-square"></i> Submit
                                    </button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
<?php echo JsValidator::formRequest('App\Http\Requests\Admin\UpdateHappyClientRequest','#happyclientUpdate'); ?>

<script>
$('input[name=photo]').on('change', function(){
        changeImage(this);
    })
    function changeImage(input) {
  var reader;

  if (input.files && input.files[0]) {
    reader = new FileReader();

    reader.onload = function(e) {
      $('.preview_image').attr('src', e.target.result);
    }
    reader.readAsDataURL(input.files[0]);
  }
}

       
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/admin/happy_clients/edit.blade.php ENDPATH**/ ?>
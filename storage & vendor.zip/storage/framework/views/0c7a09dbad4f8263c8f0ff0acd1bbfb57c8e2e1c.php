<?php $__env->startSection('content'); ?>
    <div class="row">
        <!-- DOM dataTable -->
        <div class="col-md-12">
            <div class="widget">
                <header class="widget-header">
                    <h4 class="widget-title" style="color: blue">Appointment Details</h4>
                </header><!-- .widget-header -->
                <hr class="widget-separator">
                <div class="widget-body">
                    <div class="table-responsive">

                        <table border="1" class="table table-bordered mg-b-0">
                            <tr>
                                <th>Appointment Number</th>
                                <td><?php echo e($appointment->AppointmentNumber); ?></td>
                                <th>Patient Name</th>
                                <td><?php echo e($appointment->Name); ?></td>
                            </tr>

                            <tr>
                                <th>Mobile Number</th>
                                <td><?php echo e($appointment->MobileNumber); ?></td>
                                <th>Email</th>
                                <td><?php echo e($appointment->Email); ?></td>
                            </tr>
                            <tr>
                                <th>Appointment Date</th>
                                <td><?php echo e($appointment->AppointmentDate); ?></td>
                                <th>Appointment Time</th>
                                <td><?php echo e($appointment->AppointmentTime); ?></td>
                            </tr>

                            <tr>
                                <th>Apply Date</th>
                                <td><?php echo e($appointment->ApplyDate); ?></td>
                                <th>Appointment Final Status</th>

                                <td colspan="4">
                                    <?php if($appointment->Status == ''): ?>
                                        Not yet updated
                                    <?php endif; ?>

                                    <?php if($appointment->Status == 'Approved'): ?>
                                        Your appointment has been approved
                                    <?php endif; ?>

                                    <?php if($appointment->Status == 'Cancelled'): ?>
                                        Your appointment has been cancelled
                                    <?php endif; ?>

                                </td>
                            </tr>
                            <tr>

                                <th>Remark</th>
                                <?php if($appointment->Remark == ''): ?>
                                    <td colspan="3">Not Updated Yet</td>
                                <?php else: ?>
                                    <td colspan="3"><?php echo e($appointment->Remark); ?></td>
                                <?php endif; ?>

                        </table>
                        <br>

                        <?php if($appointment->Status == ''): ?>
                            <p align="center" style="padding-top: 20px">
                                <button class="btn btn-primary waves-effect waves-light w-lg" data-toggle="modal"
                                    data-target="#myModal">Take Action</button>
                            </p>
                        <?php endif; ?>
                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Take Action</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-bordered table-hover data-tables">

                                            <form method="post" name="submit"
                                                action="<?php echo e(route('appointment.update', $appointment->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('put'); ?>
                                                <tr>
                                                    <th>Remark :</th>
                                                    <td>
                                                        <textarea name="Remark" placeholder="Remark" rows="12" cols="14" class="form-control wd-450" required="true"></textarea>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <th>Status :</th>
                                                    <td>

                                                        <select name="Status" class="form-control wd-450" required="true">
                                                            <option value="Approved" selected="true">Approved</option>
                                                            <option value="Cancelled">Cancelled</option>

                                                        </select>
                                                    </td>
                                                </tr>
                                        </table>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="submit" name="submit" class="btn btn-primary">Update</button>

                                        </form>


                                    </div>


                                </div>
                            </div>

                        </div>

                    </div><!-- .widget-body -->


                </div><!-- .widget -->
            </div><!-- END column -->


        </div><!-- .row -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.doctor', ['title' => ' Details Appointment'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Doctor-Appointment-System\resources\views/doctor/appointment/appointmentdetail.blade.php ENDPATH**/ ?>
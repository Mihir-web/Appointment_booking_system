

<?php $__env->startSection('content'); ?>
<!-- Header Banner -->
<section class="banner-header section-padding bg-img" data-overlay-dark="8" data-background="<?php echo e(asset('assets/img/slider/11.jpg')); ?>">
        <div class="v-middle">
            <div class="container">
                <div class="col-md-12 text-center">
                    <h6 class="wow slideInDown">Check Out</h6>
                    <h1 class="wow fadeInUp"><span>Our</span> Inventory</h1>
                </div>
            </div>
        </div>
    </section>
    <!-- Details -->
    <section class="cars2 mt-60 mb-60">
        <div class="container" id="cars">
            <div class="row d-flex justify-content-between mb-4" >
                
               
                    <form action="<?php echo e(route('inventorylist')); ?>" method="get" class="form1 brdr mb-5 clearfix">

                        <div class="row">
                        <div class="col-lg-3 col-12 c4">
                            <div class="select1_wrapper">
                                <label>Choose Car Type</label>
                                <div class="select1_inner">
                                    <select class="select2 select" name="car_type" style="width: 100%">
                                        <option selected disabled value="">Select Car Type</option>
                                        <option value="Convertible" <?php echo e(isset($filter['car_type']) && !empty($filter['car_type']) && $filter['car_type'] == 'Convertible' ? 'selected' : ''); ?>>Convertible</option>
                                        <option value="Coupe" <?php echo e(isset($filter['car_type']) && !empty($filter['car_type']) && $filter['car_type'] == 'Coupe' ? 'selected' : ''); ?>>Coupe</option>
                                        <option value="Hatchback" <?php echo e(isset($filter['car_type']) && !empty($filter['car_type']) && $filter['car_type'] == 'Hatchback' ? 'selected' : ''); ?>>Hatchback</option>
                                        <option value="Minivan" <?php echo e(isset($filter['car_type']) && !empty($filter['car_type']) && $filter['car_type'] == 'Minivan' ? 'selected' : ''); ?>>Minivan</option>
                                        <option value="Pickup Truck" <?php echo e(isset($filter['car_type']) && !empty($filter['car_type']) && $filter['car_type'] == 'Pickup Truck' ? 'selected' : ''); ?>>Pickup Truck</option>
                                        <option value="Sedan" <?php echo e(isset($filter['car_type']) && !empty($filter['car_type']) && $filter['car_type'] == 'Sedan' ? 'selected' : ''); ?>>Sedan</option>
                                        <option value="Sports Car" <?php echo e(isset($filter['car_type']) && !empty($filter['car_type']) && $filter['car_type'] == 'Sports Car' ? 'selected' : ''); ?>>Sports Car</option>
                                        <option value="Station Wagon" <?php echo e(isset($filter['car_type']) && !empty($filter['car_type']) && $filter['car_type'] == 'Station Wagon' ? 'selected' : ''); ?>>Station Wagon</option>
                                        <option value="SUV" <?php echo e(isset($filter['car_type']) && !empty($filter['car_type']) && $filter['car_type'] == 'SUV' ? 'selected' : ''); ?>>SUV</option>
                                        <option value="Van" <?php echo e(isset($filter['car_type']) && !empty($filter['car_type']) && $filter['car_type'] == 'Van' ? 'selected' : ''); ?>>Van</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-12 c4">
                            <div class="select1_wrapper">
                                <label>Filter By Car Brand</label>
                                <div class="select1_inner">
                                    <select class="select2 select" name="brand" style="width: 100%">
                                        <option value="" selected disabled>Car Brand</option>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($brand_data->id); ?>" <?php echo e(isset($filter['brand']) && !empty($filter['brand']) && $filter['brand'] == $brand_data->id ? 'selected' : ''); ?>><?php echo e($brand_data->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-12 c4">
                            <div class="select1_wrapper">
                                <label>Filter By Year</label>
                                <div class="select1_inner">
                                    <select class="select2 select" name="model_year" style="width: 100%">
                                        <option value="" selected disabled>Model Year</option>
                                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($year_data->year); ?>" <?php echo e(isset($filter['model_year']) && !empty($filter['model_year']) && $filter['model_year'] == $year_data->year ? 'selected' : ''); ?>><?php echo e($year_data->year); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-12">
                            <div class="select1_wrapper">
                                <label>Filter By Transmission</label>
                                <div class="select1_inner">
                                    <select class="select2 select" name="transmission_type" style="width: 100%">
                                        <option selected disabled>Transmission Type</option>
                                        <option value="A" <?php echo e(isset($filter['transmission_type']) && !empty($filter['transmission_type']) && $filter['transmission_type'] == 'A' ? 'selected' : ''); ?>>Automatic</option>
                                        <option value="M" <?php echo e(isset($filter['transmission_type']) && !empty($filter['transmission_type']) && $filter['transmission_type'] == 'M' ? 'selected' : ''); ?>>Manual</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="inventory-search mb-3 col-lg-6 col-12">
                            <input type="search_input" name="search" value="<?php echo e(isset($filter['search']) && !empty($filter['search']) ? $filter['search'] : ''); ?>" placeholder="Search By Name, and Model">
                        </div>
                    
                        <div class="col-lg-4 col-12">
                            <button type="submit" class="button-4">Filter</button>
                            <a href="<?php echo e(route('inventorylist')); ?>"><button type="button" class="button-3">Reset</button></a>
                        </div>
                        <div class="col-lg-4 col-12">
                        <?php echo e($inventory->withQueryString()->links('vendor.pagination.custom_page_showing')); ?>

                        </div>
                        </div>
                    </form>
                   
            <div class="row" id="cars">
                <div class="col-lg-12 col-md-12 car-list">
                    <div class="row list d-flex">
                            <!-- New Data start -->
                            <?php if($inventory->count() > 0): ?>
                            <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                            
                                <div class="item">
                                    <?php
                                        $photo = asset('assets/img/default_image.jpg');
                                        if(isset($inventory_data->photo) && !empty($inventory_data->photo)){
                                            $photo = asset('assets/img/cars/'.$inventory_data->photo);
                                        }
                                        
                                    ?>
                                    <a href="<?php echo e(route('inventorydetail',['alias_name'=> $inventory_data->alias, 'alias_id' =>  $inventory_data->alias_id])); ?>" class="d-inline"><figure><img src="<?php echo e($photo); ?>" alt="" class="img-fluid"></figure> </a>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"><?php echo e($inventory_data->name); ?> <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;"><?php echo e($inventory_data->trim); ?></span></h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> <?php echo e($inventory_data->model); ?></div>
                                                    <div><span class="car_listing_detail">Transmission: </span> <?php echo e($inventory_data->transmission_type == 'A'?'Auto':'Manual'); ?></div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> <?php echo e($inventory_data->engine); ?> L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> <?php echo e(number_format($inventory_data->km_driven)); ?></div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> <?php echo e($inventory_data->exterior_color); ?>

                                                    </div>
                                                    <div><span class="car_listing_detail">Interior: </span> <?php echo e($inventory_data->interior_color); ?>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$<?php echo e(number_format($inventory_data->biweekly_price)); ?> <span>/ Biwk (Tax Inc.)</span>
                                                        <p><?php echo e(number_format($inventory_data->biweekly_price_percentage,2)); ?>% for <?php echo e(number_format($inventory_data->biweekly_installment_period)); ?> months</p>
                                                    </div>
                                                    <div class="price">$<?php echo e(number_format($inventory_data->full_price)); ?>

                                                    </div>
                                                </div> <a href="<?php echo e(route('inventorydetail',['alias_name'=> $inventory_data->alias, 'alias_id' =>  $inventory_data->alias_id])); ?>" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                           <?php else: ?>
                           <div class="text-center">
                                <h1><span>No</span> Record Found!</h1>
                        </div>
                           <?php endif; ?>
                          
                          <?php echo e($inventory->withQueryString()->links('vendor.pagination.custom_pagination')); ?> 
                        
                        <!-- New Data End -->
                    </div>
                    <!-- Pagination -->
                    <!-- <div class="pagination"></div> -->
                    <!-- <div class="row">
                        <div class="col-lg-12 col-12 col-md-12 mt-30 text-center d-flex justify-content-center wow fadeInUp">
                            <ul class="pagination pagination-wrap">
                                <li><a href="cars.html"><i class="ti-angle-left"></i></a></li>
                                <li><a href="cars.html">1</a></li>
                                <li><a href="cars.html" class="active">2</a></li>
                                <li><a href="cars.html">3</a></li>
                                <li><a href="cars.html"><i class="ti-angle-right"></i></a></li>
                            </ul>
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
        </div>
    </section>
    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Lets Talk -->
    <section class="lets-talk bg-img bg-fixed section-padding" data-overlay-dark="5" data-background="<?php echo e(asset('assets/img/slider/3.jpg')); ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h6 class="wow slideInDown">Contact Us</h6>
                    <h5 class="wow zoomIn">Want to reach out to us?</h5>
                    <p>Don't hesitate and send us a message.</p> <a href="tel:+6478966642"
                        class="button-1 mt-15 mb-15 mr-10 wow fadeInLeft"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a> <a
                        href="<?php echo e(route('contactus')); ?>" class="button-2 mt-15 mb-15 wow fadeInRight">Contact Us <span
                            class="ti-arrow-top-right"></span></a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/inventoryListing.blade.php ENDPATH**/ ?>
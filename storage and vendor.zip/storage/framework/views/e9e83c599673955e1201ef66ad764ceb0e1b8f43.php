

<?php $__env->startSection('internal_css'); ?>
<style>
.image_preview{
    background-color:#e6e8f0 !important;
    padding:10px 20px 10px 10px;
    width:100%;
    border-radius:8px;
    margin: 5px 0 5px 25px;
}
.image_preview img{
    border:1px solid gray;
    height:100%;
    width:100px;
    border-radius:8px;
    margin-right:20px;
}
.image_preview:hover{
    border:1px solid gray;
}

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="p-lg-5 p-4">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4">Add Inventory Images</h1>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form class="user" id="inventoryCreate" method="POST" enctype="multipart/form-data" action="<?php echo e(route('adminInventoryGalleryStore')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="parent_record_id" value="<?php echo e($parent_id); ?>">
                            <div class="form-group row">
                                <label for="photo" class="col-12 text-dark">
                                    Upload Photo(s) <span class="text-danger">*</span>
                                    <div class="image_upload text-center p-2 form_input" style="height:auto; width:100%; border-radius:10px; border:dashed 2px #d1d3e2;">
                                        <img src="<?php echo e(asset('admin/assets/img/upload_image.png')); ?>" height="80px" width="80px" class="preview_image"/>
                                        <input type="file" name="photo[]" id="photo" style="width:1px; height:1px; visibility: hidden;" accept="image/jpeg" multiple/>
                                        <p class="text-secondary">Only JPG, JPEG files are allowed, and file should not exceed size of 5mb.</p>
                                    </div>
                                </label>
                                <div id="selctedimgs" class="col-12">
                                    
                                </div>
                            </div>
                            <div class="float-right mb-4">
                                <a href="<?php echo e(route('adminInventory')); ?>" class="btn btn-user btn-outline btn-outline-secondary">
                                    <i class="fa-solid fa-xmark"></i> Cancel
                                </a>
                                <button name="add_inventory_gallery" type="submit" value="1" class="btn btn-success btn-user add_inventory_gallery" disabled>
                                    <i class="fa-solid fa-up-right-from-square"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

<script>

$("#photo").change( function(event) {
   $('#selctedimgs').html('');
   let html_content = `<div class="row w-75">`;
  var count = event.target.files.length;
    let flag = true;
  for (var i = 0; i < count; ++i) {
    let preview_image_url = "";
    let file;
    if (event.target.files[i].type == "image/jpeg") {

      file = event.target.files[i];
      if (file) {
        preview_image_url = URL.createObjectURL(file)
      }
    
      if (event.target.files[i].size <= 5242880) {
        
        html_content += `<div class='col-12 col-lg-12 h-100 w-100 image_preview d-flex justify-content-between'>
                                            <div class="d-flex justify-content-center">    
                                                <img src="`+preview_image_url+`"  class="img-fluid">
                                                <div>
                                                    `+event.target.files[i].name+`
                                                </div>
                                            </div>
                                        </div><br>`;
      } else {
        html_content += `<div class='col-12 col-lg-12 h-100 w-100 image_preview d-flex justify-content-between'>
                                            <div class="d-flex justify-content-center">    
                                                <img src="`+preview_image_url+`"  class="img-fluid">
                                                <div>
                                                    `+event.target.files[i].name+`
                                                    <div style='color:red;'>File Size Must Be less than 5MB.</div>
                                                </div>
                                            </div>
                                        </div><br>`;
                                        flag = false;
      }
    } else {
        html_content += `<div class='col-12 col-lg-12 h-100 w-100 image_preview d-flex justify-content-between'>
                                            <div class="d-flex justify-content-center">    
                                                <div>
                                                    `+event.target.files[i].name+`
                                                    <div style='color:red;'>Other File format is not allowed!</div>
                                                </div>
                                            </div>
                                        </div><br>`;
                                        flag = false;
    }
  }
  html_content += `</div>`;
  $('#selctedimgs').html(html_content);
  if(flag == true){
    $('.add_inventory_gallery').removeAttr('disabled');
  }else{
    $('.add_inventory_gallery').attr('disabled',true);
  }
})

  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/admin/inventory_gallery/create.blade.php ENDPATH**/ ?>
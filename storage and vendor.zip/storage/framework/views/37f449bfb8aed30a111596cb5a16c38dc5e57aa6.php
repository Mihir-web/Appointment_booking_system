

<?php $__env->startSection('internal_css'); ?>
<style>
    .car_images_card{
        background:#f2f2f2;
        transition:all 0.25s ease-in-out;
        box-shadow: 1px 1px 10px rgba(58, 59, 69, .15) !important;
    }
    .car_images_card:hover{
        background:#d8d8d8;
        border:1px solid gray;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="d-flex mb-4 justify-content-between">
                <h1 class="h3  text-gray-800">Inventory Gallery</h1>
                <div class="float-right">
                <a class="btn btn-outline-secondary " href="<?php echo e(route('adminInventory')); ?>"> Back</a>
                <a class="btn btn-primary " href="<?php echo e(route('adminInventoryGalleryCreate',base64_encode($parent_id))); ?>"> Add Images</a>
            </div>
             </div>
             <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success" id="alert_msg">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger" id="alert_msg">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
         
            <div class="container-fluid">
                <div class="row">
                    <?php if($inventory_gallery_images->count() > 0): ?>
                    <?php $__currentLoopData = $inventory_gallery_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory_gallery_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 card p-3 m-2 d-flex justify-content-center align-items-center car_images_card">
                    <img src="<?php echo e(asset('assets/img/cars/'.$inventory_gallery_image->photo)); ?>" class="img-fluid rounded">
                    <div>
                        <button class="btn btn-danger mt-3 delete_record" rid="<?php echo e(base64_encode($inventory_gallery_image->id)); ?>"  href="<?php echo e(route('adminInventoryGalleryDelete',base64_encode($inventory_gallery_image->id))); ?>"> Delete</button>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="w-100 text-center"><h4>No Image Found!</h4></div>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    
$('.fancybox').fancybox({
  clickContent: 'close',
  buttons: ['close']
})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/admin/inventory_gallery/list.blade.php ENDPATH**/ ?>


<?php $__env->startSection('internal_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/dataTables.bootstrap4.min.css')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="d-flex mb-4 justify-content-between">
                <h1 class="h3  text-gray-800">Financing Leads</h1>
              
             </div>
             <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success" id="alert_msg">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger" id="alert_msg">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <?php if($leads->count()): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th data-orderable="false">Status <span data-toggle="tooltip" data-placement="top" data-html="true" title="This Functionality helps you to publish/unpublish particular record.<br> So, if you don't want to show any record in front then you can unpublish that one."><i class="fa-solid fa-circle-question text-dark"></i></span></th>
                            <th data-orderable="false">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $i = 0;
                            $completed_leads = 0;
                            $pending_leads = 0;
                        ?>
                        <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            if($lead->varStatus == 0){
                                $pending_leads++;
                            }
                            if($lead->varStatus == 1){
                                $completed_leads++;
                            }
                        ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td>
                                    <?php echo e($lead->first_name); ?> <?php echo e($lead->last_name); ?>

                                </td>
                                <td><?php echo e(getDecryptedString($lead->email)); ?></td>
                                <td><?php echo e(getDecryptedString($lead->phone)); ?></td>
                                <td class="text-center">
                                    <select class="form-control form_input publish_status" name="status" url="<?php echo e(route('adminFinancingLeadStatusChange')); ?>" rid="<?php echo e(base64_encode($lead->id)); ?>">
                                        <option value="0" <?php echo e($lead->varStatus == 0? "selected":""); ?>>Pending</option>
                                        <option value="1" <?php echo e($lead->varStatus == 1? "selected":""); ?>>Completed</option>
                                    </select>
                                </td>
                                <td>
                                    <a class="btn btn-danger delete_record" rid="<?php echo e(base64_encode($lead->id)); ?>"  href="<?php echo e(route('adminFinancingLeadsDelete',base64_encode($lead->id))); ?>">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <!-- export start-->
                <!-- Button to Open the Modal -->
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#myModal">
  Export Leads <i class="fas fa-regular fa-file-excel"></i>
</button>

<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Export Financing Leads as an Excel File</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <strong>Which leads you want to export?</strong>
        
        <div class="mt-4">
          
            <div class="form-check disabled">
            <label for="export_pending" class="form-check-label">
            <input type="radio" value="0" name="export_by" class="form-check-input" id="export_pending"> Pending
            </label>
        </div>
       
            <br>
           
            <div class="form-check disabled">
            <label for="export_completed" class="form-check-label">
            <input type="radio" value="1" name="export_by" class="form-check-input" id="export_completed"> Completed
            </label>
        </div>
        
            <br>
            
            <div class="form-check disabled">
            <label for="export_all" class="form-check-label">
            <input type="radio" value="3" name="export_by" class="form-check-input" id="export_all" checked> All
            </label>
        </div>
        
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <form method="get" action="<?php echo e(route('adminFinancingLeadsexport')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="hidden_export_by" value="3">
            <button type="submit" class="btn btn-success">Export &nbsp;<i class="fas fa-regular fa-file-excel"></i></button>
        </form>
        
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
                <!-- export end -->
            </div>
            <?php else: ?>
            <div class="w-100 text-center">
                <h4>No Record Found!</h4>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('admin/assets/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
    
$(document).ready(function() {
  $('#dataTable').DataTable();
});

$('input[name=export_by]').on('change', function(){
    $('input[name=hidden_export_by]').val($(this).val());
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/admin/financing_lead/list.blade.php ENDPATH**/ ?>
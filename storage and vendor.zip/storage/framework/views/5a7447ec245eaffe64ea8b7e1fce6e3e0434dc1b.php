

<?php $__env->startSection('internal_css'); ?>
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

<style>
.rating {
  margin-top: 40px;
  border: none;
  float: left;
}

.rating > label {
  color: #90A0A3;
  float: right;
}

.rating > label:before {
  margin: 5px;
  font-size: 2em;
  font-family: FontAwesome;
  content: "\f005";
  display: inline-block;
}

.rating > input {
  display: none;
}

.rating > input:checked ~ label,
.rating:not(:checked) > label:hover,
.rating:not(:checked) > label:hover ~ label {
  color: #F79426;
}

.rating > input:checked + label:hover,
.rating > input:checked ~ label:hover,
.rating > label:hover ~ input:checked ~ label,
.rating > input:checked ~ label:hover ~ label {
  color: #FECE31;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="p-lg-5 p-4">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4">Add Testimonial</h1>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('error')): ?>
                            <div class="alert alert-danger" id="alert_msg">
                                <p><?php echo e($message); ?></p>
                            </div>
                        <?php endif; ?>

                        <form class="user" id="testimonialCreate" method="POST" enctype="multipart/form-data" action="<?php echo e(route('adminTestimonialStore')); ?>">
                        <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <div class="col-sm-12 mb-3 ">
                                    <label for="client_first_name" class="text-dark">Clients's First Name <span class="text-danger">*</span></label>
                                    <input type="text" name="client_first_name" class="form-control form_input" id="client_first_name" placeholder="Client's First Name">
                                </div>
                                <div class="col-sm-12 mb-3 ">
                                    <label for="client_last_name" class="text-dark">Clients's Last Name <span class="text-danger">*</span></label>
                                    <input type="text" name="client_last_name" class="form-control form_input" id="client_last_name" placeholder="Client's Last Name">
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="gender_type">Gender <span class="text-danger">*</span></label>
                                    <div>
                                         <label for="male">Male</label>
                                    <input type="radio" name="gender" id="male" value="M">

                                    <label for="female">Female</label>
                                    <input type="radio" name="gender"  id="female" value="F">
                                </div>
                                </div>
                                <div class="col-sm-12 mb-3 d-flex">
                                    <label for="client_last_name" class="text-dark">Rating<span class="text-danger">*</span></label>
                                    <div class="rating">
                                      <input type="radio" id="star5" name="rating" value="5" />
                                      <label class="star" for="star5" title="Awesome" aria-hidden="true"></label>
                                      <input type="radio" id="star4" name="rating" value="4" />
                                      <label class="star" for="star4" title="Great" aria-hidden="true"></label>
                                      <input type="radio" id="star3" name="rating" value="3" />
                                      <label class="star" for="star3" title="Very good" aria-hidden="true"></label>
                                      <input type="radio" id="star2" name="rating" value="2" />
                                      <label class="star" for="star2" title="Good" aria-hidden="true"></label>
                                      <input type="radio" id="star1" name="rating" value="1" />
                                      <label class="star" for="star1" title="Bad" aria-hidden="true"></label>
                                    </div>
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="message" class="text-dark">Message <span class="text-danger">*</span></label>
                                    <textarea class="w-100 text-area form_input" id="html-content" cols="42" rows="8" name="message" style="border-radius:8px; border:1px solid #d1d3e2 !important;" placeholder="Message"></textarea>
                                </div>
                                
                                </div>
                                
                                <hr>
                                <div class="float-right mb-4">
                                    <a href="<?php echo e(route('adminTestimonial')); ?>" class="btn btn-user btn-outline btn-outline-secondary">
                                        <i class="fa-solid fa-xmark"></i> Cancel
                                    </a>
                                    <button name="add_product" type="submit" value="1" class="btn btn-success btn-user">
                                        <i class="fa-solid fa-up-right-from-square"></i> Submit
                                    </button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
<?php echo JsValidator::formRequest('App\Http\Requests\Admin\AddTestimonialRequest','#testimonialCreate'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/admin/testimonial/create.blade.php ENDPATH**/ ?>
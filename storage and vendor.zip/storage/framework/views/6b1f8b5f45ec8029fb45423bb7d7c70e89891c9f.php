

<?php $__env->startSection('content'); ?>
<!-- Header Banner -->
<section class="banner-header section-padding bg-img" data-overlay-dark="8" data-background="<?php echo e(asset('assets/img/slider/11.jpg')); ?>">
        <div class="v-middle">
            <div class="container">
                <div class="col-md-12 text-center">
                    <h6 class="wow slideInDown">Check Out</h6>
                    <h1 class="wow fadeInUp"><span>Our</span> Inventory</h1>
                </div>
            </div>
        </div>
    </section>
    <!-- Details -->
    <section class="cars2 mt-60 mb-60">
        <div class="container" id="cars">
            <div class="row d-flex justify-content-between mb-4" >
                <div class="col-md-4 mb-3">
                    <div class="inventory-search search">
                        <form action="#">
                            <input type="search_input" namw="search" placeholder="Search By Name, and Model" required>
                            <button type="submit"><i class="ti-arrow-top-right"></i></button>
                        </form>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 text-lg-end">
                    <a class="button-4" data-bs-toggle="collapse" href="#collapseExample" role="button"
                        aria-expanded="false" aria-controls="collapseExample">
                        Filters
                    </a>
                </div>
            </div>
            <div class="col-md-12 col-lg-12 col-12 collapse mb-30" id="collapseExample">
                <div class="card card-body">
                    <h4>Filters</h4>
                    <form action="#0" class="form1 brdr clearfix">
                        <div class="col2 c3">
                            <div class="select1_wrapper">
                                <label>Choose Car Type</label>
                                <div class="select1_inner">
                                    <select class="select2 select" style="width: 100%">
                                        <option value="0">Filter By Car Type</option>
                                        <option value="1">All</option>
                                        <option value="2">Luxury Cars</option>
                                        <option value="3">Sport Cars</option>
                                        <option value="4">SUVs</option>
                                        <option value="5">Convertible</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col2 c4">
                            <div class="select1_wrapper">
                                <label>Filter By Car Brand</label>
                                <div class="select1_inner">
                                    <select class="select2 select" style="width: 100%">
                                        <option value="0">Filter By Car Brand</option>
                                        <option value="BMW">BMW</option>
                                        <option value="Audi">Audi</option>
                                        <option value="Mercedes">Mercedes</option>
                                        <option value="Volvo">Volvo</option>
                                        <option value="Jeep">Jeep</option>
                                        <option value="Subaru">Subaru</option>
                                        <option value="Volkswagen">Volkswagen</option>
                                        <option value="Hyundai">Hyundai</option>
                                        <option value="Honda">Honda</option>
                                        <option value="Lexus">Lexus</option>
                                        <option value="Mitsubishi">Mitsubishi</option>
                                        <option value="Nissan">Nissan</option>
                                        <option value="Ford">Ford</option>
                                        <option value="Toyota">Toyota</option>
                                        <option value="Dodge">Dodge</option>
                                        <option value="Kia">Kia</option>
                                        <option value="Chrysler">Chrysler</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col2 c4">
                            <div class="select1_wrapper">
                                <label>Filter By Year</label>
                                <div class="select1_inner">
                                    <select class="select2 select" style="width: 100%">
                                        <option value="0">Filter By Year</option>
                                        <option value="2001">2001</option>
                                        <option value="2002">2002</option>
                                        <option value="2003">2003</option>
                                        <option value="2004">2004</option>
                                        <option value="2005">2005</option>
                                        <option value="2006">2006</option>
                                        <option value="2007">2007</option>
                                        <option value="2008">2008</option>
                                        <option value="2009">2009</option>
                                        <option value="2010">2010</option>
                                        <option value="2011">2011</option>
                                        <option value="2012">2012</option>
                                        <option value="2013">2013</option>
                                        <option value="2014">2014</option>
                                        <option value="2015">2015</option>
                                        <option value="2016">2016</option>
                                        <option value="2017">2017</option>
                                        <option value="2018">2018</option>
                                        <option value="2019">2019</option>
                                        <option value="2020">2020</option>
                                        <option value="2021">2021</option>
                                        <option value="2022">2022</option>
                                        <option value="2023">2023</option>
                                        <option value="2024">2024</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col2 c5">
                            <div class="select1_wrapper">
                                <label>Filter By Exterior Color</label>
                                <div class="select1_inner">
                                    <select class="select2 select" style="width: 100%">
                                        <option value="0">Filter By Exterior Color</option>
                                        <option value="1">White</option>
                                        <option value="2">Black</option>
                                        <option value="3">Gray</option>
                                        <option value="4">Red</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col3 c5">
                            <div class="select1_wrapper">
                                <label>Filter By Interior Color</label>
                                <div class="select1_inner">
                                    <select class="select2 select" style="width: 100%">
                                        <option value="0">Filter By Interior Color</option>
                                        <option value="1">White</option>
                                        <option value="2">Black</option>
                                        <option value="3">Gray</option>
                                        <option value="4">Red</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col2 c5">
                            <div class="select1_wrapper">
                                <label>Filter By Transmission</label>
                                <div class="select1_inner">
                                    <select class="select2 select" style="width: 100%">
                                        <option value="0">Filter By Transmission</option>
                                        <option value="1">Automatic</option>
                                        <option value="2">Manual</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col3 c6">
                            <button type="submit" class="button-4">Filter</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row" id="cars">
                <div class="col-lg-12 col-md-12 car-list">
                    <div class="row list d-flex">
                            <!-- New Data start -->
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure><img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"></figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">Toyota CHR <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">XLE FWD</span></h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2022</div>
                                                    <div><span class="car_listing_detail">Transmission: </span> Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2.0 L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 65,353</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Black
                                                    </div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$215 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$26,500
                                                    </div>
                                                </div> <a href="./toyota-chr-xle-fwd-1713691167.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">Hyundai Elantra Preferred <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">Preferred</span></h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2020</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 1.5 L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 68,200</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                                
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$173 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$21,500</div>
                                                </div> <a href="./hyundai-elantra-preferred-1713691728.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">Hyundai Tucson <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">SE AWD</span></h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2017</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2.0 L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 104,000</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$222 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 60 months</p>
                                                    </div>
                                                    <div class="price">$21,000</div>
                                                </div> <a href="./hyundai-tucson-1713692931.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">Ford Fusion Hybrid <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">Titanium FWD</span></h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2020</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2.0 L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 78,860</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$195 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$23,999</div>
                                                </div> <a href="./ford-fusion-hybrid-1713693571.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">Volkswagen Jetta <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">Highline FWD</span></h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2020</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 1.4 L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 88,545</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Silver</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$187 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$22,999</div>
                                                </div> <a href="./volkswagen-jetta-1713693770.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure><img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"></figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">Hyundai Sonata <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">SE FWD</span></h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2017</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2.4L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 1,29,937</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White
                                                    </div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$170 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 72 months</p>
                                                    </div>
                                                    <div class="price">$18,500
                                                    </div>
                                                </div> <a href="./hyundai-sonata-1713694242.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure><img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"></figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">Subaru WRX <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">STI</span></h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2017</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Manual</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2.5L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 108,000</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White
                                                    </div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$255 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 72 months</p>
                                                    </div>
                                                    <div class="price">$27,999
                                                    </div>
                                                </div> <a href="./subaru-wrx-1713694608.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure><img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"></figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">Toyota Corolla <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">LE Upgrade FWD</span></h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2022</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 1.8L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 60,013</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Black</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$207 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$25,500
                                                    </div>
                                                </div> <a href="./toyota-corolla-1713694870.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure><img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"></figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">Toyota Camery <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">SE FWD</span></h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2022</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2.4L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 61,300</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$243 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$29,899
                                                    </div>
                                                </div> <a href="./toyota-camery-1713695085.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure><img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"></figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">Toyota Corolla <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">LE FWD</span></h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2021</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 1.8L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 75,300</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Grey</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$195 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$23,999
                                                    </div>
                                                </div> <a href="./toyota-corolla-1713705462.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure><img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"></figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">Toyota Corolla <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">LE FWD</span></h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2022</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 1.8L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 75,000</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Blue</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$203 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$24,899
                                                    </div>
                                                </div> <a href="./toyota-corolla-1713705724.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">Kia Forte
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">EX FWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2021</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2.0L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 91,318</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$175 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$21,599</div>
                                                </div> <a href="./kia-forte-1713705890.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">Honda Civic
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">Touring</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2017</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 1.5L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 120,218</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Black</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$211 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 60 months</p>
                                                    </div>
                                                    <div class="price">$19,999</div>
                                                </div> <a href="./honda-civic-1713706437.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Toyota RAV 4
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">LE FWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2022</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2.5L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 62,990</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Black</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$273 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$33,599</div>
                                                </div> <a href="./toyota-rav-4-1713706696.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Toyota RAV 4
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">LE FWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2022</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2.5L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 61,990</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Black</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$273 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$33,599</div>
                                                </div> <a href="./toyota-rav-4--1713706932.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Volkswagen Passat
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">Comfort Line</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2020</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2.0L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 86,623</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Black</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$162 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$20,000</div>
                                                </div> <a href="./volkswagen-passat-1713707070.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Honda Odyssey
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">Touring</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2019</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 3.5L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 63,000</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Silver</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$356 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 72 months</p>
                                                    </div>
                                                    <div class="price">$38,999</div>
                                                </div> <a href="honda-odyssey-1713707730.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Mercedes
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">C300 AWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2016</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2.0L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 140,000</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Black</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$248 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 60 months</p>
                                                    </div>
                                                    <div class="price">$23,500</div>
                                                </div> <a href="./mercedes-1713708053.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Honda HRV
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">LX AWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2021</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 1.8L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 85,000</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Black</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$202 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$24,899</div>
                                                </div> <a href="./honda-hrv-1713708341.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Hyundai Elantra
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">SEL FWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2021</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 87,873</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Grey</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$185 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$22,800</div>
                                                </div> <a href="./hyundai-elantra-1713708532.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Lexus
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">NX 300</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2020</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 77,554</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Black</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$276 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$33,999</div>
                                                </div> <a href="./lexus-1713708854.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> BMW X5
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">X DRIVE 35i</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2018</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 3.0L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 80,859</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$325 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 72 months</p>
                                                    </div>
                                                    <div class="price">$35,599</div>
                                                </div> <a href="./bmw-x5-1713709140.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Mitsubishi RVR
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">SE FWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2023</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 10,200</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Silver</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$278 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$34,300</div>
                                                </div> <a href="./mitsubishi-rvr-1713709441.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Subaru
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">WRX</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2018</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 105,126</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Grey</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$241 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 72 months</p>
                                                    </div>
                                                    <div class="price">$26,400</div>
                                                </div> <a href="./subaru-1713709702.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name">  Jeep Wrangler
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">Unlimited Sahara</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2021</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 86,819</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$308 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$37,999</div>
                                                </div> <a href="./jeep-wrangler-1713709965.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Audi Q5
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">Premium Quattro</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2021</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 83,397</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$252 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$39,995</div>
                                                </div> <a href="./audi-q5-1713710304.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Dodge Charger
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">GT RWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2021</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 3.6L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 71,588</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Brown</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$252 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$30,999</div>
                                                </div> <a href="./dodge-charger-1713710547.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Chrysler 300
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">Touring L AWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2022</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 3.6L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 62,120</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Black</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$308 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$37,999</div>
                                                </div> <a href="./chrysler-300-1713710836.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Volvo XC40
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">T5R-Design AWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2021</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 68,215</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$315 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$38,850</div>
                                                </div> <a href="./volvo-xc40-1713711088.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Honda Pilot
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">Touring AWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2020</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 3.5L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 44,000</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Silver</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$403 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$49,500</div>
                                                </div> <a href="./honda-pilot-1713711356.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Hyundai Ioniq Hybrid
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">SEL FWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2019</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 1.6L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 99,382</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Silver</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$183 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 72 months</p>
                                                    </div>
                                                    <div class="price">$19,999</div>
                                                </div> <a href="./hyundai-ioniq-hybrid-1713711657.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Volkswagen Jetta
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">Highline</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2021</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 1.5L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 88,870</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> Black</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$187 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$22,999</div>
                                                </div> <a href="./volkswagen-jetta-1713711887.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Hyundai Sonata
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">SEL Plus FWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2022</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 1.6L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> N/A</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$216 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$26,599</div>
                                                </div> <a href="./hyundai-sonata-1713712021.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Hyundai Sonata
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">SEL Plus FWD</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2021</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 1.6L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 82,075</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$208 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 84 months</p>
                                                    </div>
                                                    <div class="price">$25,599</div>
                                                </div> <a href="./hyundai-sonata-1713712143.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-12 mb-30 wow fadeInUp">
                                <div class="item list">
                                    <figure> <img src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" alt="" class="img-fluid"> </figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"> Nissan Altima
                                                <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;">SV</span>
                                            </h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> 2018</div>
                                                    <div><span class="car_listing_detail">Transmission: </span>Auto</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> 2.5L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> 99,000</div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> White</div>
                                                    <div><span class="car_listing_detail">Interior: </span> Black</div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$170 <span>/ Biwk (Tax Inc.)</span>
                                                        <p>7.99% for 72 months</p>
                                                    </div>
                                                    <div class="price">$18,599</div>
                                                </div> <a href="./nissan-altima-1713712249.html" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        <!-- New Data End -->
                    </div>
                    <!-- Pagination -->
                    <!-- <div class="pagination"></div> -->
                    <!-- <div class="row">
                        <div class="col-lg-12 col-12 col-md-12 mt-30 text-center d-flex justify-content-center wow fadeInUp">
                            <ul class="pagination pagination-wrap">
                                <li><a href="cars.html"><i class="ti-angle-left"></i></a></li>
                                <li><a href="cars.html">1</a></li>
                                <li><a href="cars.html" class="active">2</a></li>
                                <li><a href="cars.html">3</a></li>
                                <li><a href="cars.html"><i class="ti-angle-right"></i></a></li>
                            </ul>
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
        </div>
    </section>
    <!-- Lets Talk -->
    <section class="lets-talk bg-img bg-fixed section-padding" data-overlay-dark="5" data-background="<?php echo e(asset('assets/img/slider/3.jpg')); ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h6 class="wow slideInDown">Contact Us</h6>
                    <h5 class="wow zoomIn">Want to reach out to us?</h5>
                    <p>Don't hesitate and send us a message.</p> <a href="tel:+6478966642"
                        class="button-1 mt-15 mb-15 mr-10 wow fadeInLeft"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a> <a
                        href="contact.html" class="button-2 mt-15 mb-15 wow fadeInRight">Contact Us <span
                            class="ti-arrow-top-right"></span></a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/inventorylisting.blade.php ENDPATH**/ ?>
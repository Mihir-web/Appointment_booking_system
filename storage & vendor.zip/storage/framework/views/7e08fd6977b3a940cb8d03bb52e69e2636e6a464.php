<?php $__env->startSection('content'); ?>
    <div class="row">
        <!-- DOM dataTable -->
        <div class="col-md-12">
            <div class="widget">
                <header class="widget-header">
                    <h4 class="widget-title">All Appointment</h4>
                </header><!-- .widget-header -->
                <hr class="widget-separator">
                <div class="widget-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover js-basic-example dataTable table-custom">
                            <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>Appointment Number</th>
                                    <th>Patient Name</th>
                                    <th>Mobile Number</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>Action</th>

                                </tr>
                            </thead>

                            <tbody>
                                <?php
                                    $no = 1;
                                ?>
                                <?php if($appointments != null || $appointments != 0): ?>
                                    <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($appointment->AppointmentNumber); ?></td>
                                            <td><?php echo e($appointment->Name); ?></td>
                                            <td><?php echo e($appointment->MobileNumber); ?></td>
                                            <td><?php echo e($appointment->Email); ?></td>

                                            <?php if($appointment->Status == ''): ?>
                                                <td>Not Updated Yet</td>
                                            <?php else: ?>
                                                <td><?php echo e($appointment->Status); ?></td>
                                            <?php endif; ?>

                                            <td><a href="<?php echo e(route('detailAppointment.show', [$appointment->id, $appointment->AppointmentNumber])); ?>"
                                                    class="btn btn-primary">View</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8"> No record found against this search</td>
                                    </tr>
                                <?php endif; ?>

                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>S.No</th>
                                    <th>Appointment Number</th>
                                    <th>Patient Name</th>
                                    <th>Mobile Number</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div><!-- .widget-body -->
            </div><!-- .widget -->
        </div><!-- END column -->


    </div><!-- .row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.doctor', ['title' => ' All Appointment'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Doctor-Appointment-System\resources\views/doctor/appointment/allAppointment/index.blade.php ENDPATH**/ ?>
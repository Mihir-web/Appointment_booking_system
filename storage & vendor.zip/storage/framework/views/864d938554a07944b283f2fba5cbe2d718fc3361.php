<?php $__env->startSection('content'); ?>
    <div class="simple-page-form animated flipInY" id="login-form">
        <h4 class="form-title m-b-xl text-center">Sign In With Your DAMS Account</h4>
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Enter Registered Email ID" required="true"
                    name="email">
            </div>

            <div class="form-group">
                <input type="password" class="form-control" placeholder="Password" name="password" required="true">
            </div>


            <input type="submit" class="btn btn-primary" name="login" value="Sign IN">
        </form>
        <hr />
        <a href="<?php echo e(route('register')); ?>">Signup/Registration</a>
    </div><!-- #login-form -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <p>
        <?php if(Route::has('password.request')): ?>
            <a href="<?php echo e(route('password.request')); ?>">FORGOT YOUR PASSWORD ?</a>
        <?php endif; ?>
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Login.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Doctor-Appointment-System\resources\views/auth/login.blade.php ENDPATH**/ ?>